﻿using Avalonia.Controls; 

namespace Avalonia.Gif.Demo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}