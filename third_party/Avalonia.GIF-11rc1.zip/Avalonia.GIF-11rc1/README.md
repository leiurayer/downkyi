## Avalonia.GIF

GIF image renderer and player for Avalonia UI Framework.

![demo](./demo.gif)
 
