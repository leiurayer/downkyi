﻿namespace Avalonia.Gif
{
    internal enum BgWorkerState
    {
        Null,
        Start,
        Running,
        Paused,
        Complete,
        Dispose
    }
}