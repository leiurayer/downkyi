namespace Avalonia.Gif.Decoding
{
    internal enum ExtensionType
    {
        GraphicsControl = 0xF9,
        Application = 0xFF
    }
}